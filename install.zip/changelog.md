## v2.0.1
- Updated Hosts File
- Unused script removed
---
## v2.0.1
- Updated hosts file
---
## v2.0.0
- Updated source
- Updated hosts file
---
## v1.2
- Updated hosts file
---
## v1.1
- Updated hosts file
---
## v1.0
- First release
