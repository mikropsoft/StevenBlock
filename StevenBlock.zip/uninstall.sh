#!/system/bin/sh

rm -f "/data/local/tmp/stevenblock.log" 2>/dev/null