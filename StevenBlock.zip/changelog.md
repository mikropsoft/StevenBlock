# StevenBlock - AdBlock Module

**Need help?**  
You can contact me through:  
- **Telegram**: [@microzort](https://t.me/microzort) 💬  
- **GitHub**: Open an issue on the repository.  

*Telegram and GitHub are the only official support channels for this module.*
