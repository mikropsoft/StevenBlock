# StevenBlock - AdBlock Module

**Need help?**  
Contact me on Telegram: [@microzort](https://t.me/microzort) 💬

*Telegram is the only support channel for this module.*
