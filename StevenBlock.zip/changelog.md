# 🚫 StevenBlock — AdBlock Module

---

## Official Support & Community

Looking for support, updates, or want to connect with others?  
Join our official group to stay in the loop and engage with the StevenBlock community!

> **[Telegram](https://t.me/stevenblockmodule)** is the only official support channel for this module.
